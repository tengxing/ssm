# ssm

## 安装说明：1 建立ssm数据库 2 导入ssm.sql 3 修改数据路密码

## 使用说明: 部署后网址打开：localhost:8080/ssm 
